import React from 'react'
import './Footer.css'
import {FaHome, FaPhone, FaMailBulk, FaInstagram, FaLinkedin, FaGithub} from 'react-icons/fa';

const Footer = () => {
    let intro = "Hi! I am a front-end web developer based in Gurgaon, Haryana. My interest in Web Developement sparked during my University Placement year. I later started worked on learning new technologies which helped me turn ideas into websites. Let's connect and discuss over a cup of coffee.";

  return (
    <div className = 'footer'>
        <div className = 'footer__container'>
            <div className='footer__leftItem'>
                <div className='footer_location'>
                <FaHome size = {20} style = {{color: '#E6DDC4',
            marginRight : '2rem'}}/>
            <p>Gurugram, Haryana</p>
            </div>
            <div className='footer__phone'>
                <h4>
            <FaPhone size= {20} style = {{color: '#E6DDC4',
            marginRight : '2rem'}}/>+91 XXXXXXXXXX</h4>
            </div>
            <div className='footer__email'>
                <h4>
            <FaMailBulk size= {20} style = {{color: '#E6DDC4',
            marginRight : '2rem'}}/>zeyasadaf259@gmail.com</h4>
            </div>
            </div>
            <div classname = 'footer__rightItem'>
                <div className='footer_about'>
                <h4>About me</h4>
                
                <p>{intro}</p>
                </div>
                <div className='footer_RightSocial'>
                <FaInstagram style = {{color: '#E6DDC4',
            marginRight : '2rem'}} size = {20}/>
                <FaLinkedin style = {{color: '#E6DDC4',
            marginRight : '2rem'}} size = {20}/>
                <FaGithub style = {{color: '#E6DDC4',
            marginRight : '2rem'}} size = {20}/>
                </div>
            </div>
        </div>
      
    </div>
  )
}

export default Footer
