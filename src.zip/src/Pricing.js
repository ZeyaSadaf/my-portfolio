import React from 'react'
import { Link } from 'react-router-dom'
import './Pricing.css'
const Pricing = () => {
  return (
    <div className = "pricing">
        
        <h1 className='p__heading'>Pricing</h1>
        <div className = 'pricing__cardContainer'>
            <div className = 'pricing__card'>
                <h3>
                    Basic
                </h3>
                <span className = 'bar'></span>
                <p className = 'price'><small>Rs.</small> 500</p>
                <p>3 Days</p>
                <p>3 Pages</p>
                <p>Featured</p>
                <p>Responsive Design</p>
                <Link to = '/contact' className = 'btn btnPrice'>PURCHASE
                </Link>
            </div>

            <div className = 'pricing__card'>
                <h3>
                    Basic
                </h3>
                <span className = 'bar'></span>
                <p className = 'price'><small>Rs.</small> 500</p>
                <p>3 Days</p>
                <p>3 Pages</p>
                <p>Featured</p>
                <p>Responsive Design</p>
                <Link to = '/contact' className = 'btn btnPrice'>PURCHASE
                </Link>
            </div>

            <div className = 'pricing__card'>
                <h3>
                    Basic
                </h3>
                <span className = 'bar'></span>
                <p className = 'price'><small>Rs.</small> 500</p>
                <p>3 Days</p>
                <p>3 Pages</p>
                <p>Featured</p>
                <p>Responsive Design</p>
                <Link to = '/contact' className = 'btn btnPrice'>PURCHASE
                </Link>
            </div>
        </div>
    </div>
  )
}

export default Pricing
