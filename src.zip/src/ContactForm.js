import React from 'react'
import './ContactForm.css'

const ContactForm = () => {
  return (
    <div className='contactForm'>
        <h1>~Let's Connect~</h1>
        <div>
      <form>
        <label className='contactForm__label'>Your Name</label>
        <input type = 'text' placeholder='Enter your name'></input>
        <label className='contactForm__label'>Email Address</label>
        <input type = 'email' placeholder='Your email'></input>
        <label className='contactForm__label'>Subject</label>
        <input type = 'text' placeholder='Enter your name'></input>
        <label className='contactForm__label'>Your Message</label>
        <textarea row = '6' placeholder='Type your Message Here'>
        </textarea>

        <button className = 'contactForm__button btn' type = 'submit'>Submit</button>
      </form>
      </div>
    </div>
  )
}

export default ContactForm
